{-|
Module      : Syntax.Syntax
Description : Provides the definitions of names and identifiers.
Maintainer  : pablog@ciencias.unam.mx
-}
module Syntax.Syntax (Identifier, Name) where

type Identifier = String
type Name = String